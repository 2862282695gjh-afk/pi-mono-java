# Story 设计：Web 前端 Slash Commands

> Story：CampusClaw Web 工作台支持 Slash Commands（发现、补全、执行与结果投影）
>
> 状态：Ready for implementation
>
> 日期：2026-08-28
>
> 范围：coding-agent-cli Runtime HTTP/SSE 服务与 frontend Vue 工作台
> 输入资料：[功能主设计](frontend-slash-commands.md)、[现状 Gap 分析](frontend-slash-commands-gap-analysis.md)、[低保真图](frontend-slash-command-low-fidelity.html)

## 文档信息

| 项目 | 内容 |
|---|---|
| Story 名称 | Web 前端 Slash Commands |
| 优先级 | P0：授权、解析、目录、resume、compact；P1：Skill、Extension |
| 实施主契约 | [frontend-slash-commands.md](frontend-slash-commands.md) |
| 本文职责 | 将主契约转化为可评估、可开发、可测试的 Story 设计；不覆盖主契约 |
| 非本期范围 | Extension 运行期安装或卸载、浏览器端 Extension handler、compact 取消、多实例自动恢复 |

## 先看结论

这件事可以简单理解为：用户在输入框里输入斜杠时，前端先判断它是不是一个命令。

1. 是本地命令，例如 /new、/resume，就由浏览器直接完成。
2. 是服务端命令，例如 /help、/settings、/compact、Skill 或 Extension，就调用专门的 commands 接口。
3. 不是已知命令，例如 /abc，就仍然作为普通对话发送给 Agent。
4. 只有服务端确认的命令才会被拦截，不能因为前端漏处理而进入模型。
5. compact 是唯一需要长期跟踪的异步命令：接口只表示“已开始”，最终成功或失败要从历史记录查看。

下文中出现的英文类名、接口名和错误码，都是为了方便开发人员定位代码；阅读业务逻辑时可以先看每段中文说明和表格的“说明”列。

---

## 1. Story 背景

### 1.1 需求来源

当前 Web 工作台会把所有以斜杠开头的输入当作普通消息发送给 Agent。因此用户输入 /model 或 /compact 时，模型会把它当成聊天内容，而不是执行会话操作。

仓内虽然保留了早期终端版本的命令代码，但它没有接到 Web 服务；而且它会修改用户参数、不能正确处理换行。这里需要单独做一套 Web 命令入口，并让前后端遵守同一套解析规则。

### 1.2 需求价值

- 让用户通过斜杠发现和执行会话操作，避免控制意图被模型误解并消耗 token。
- 让 Skill 由服务端安全读取受管目录、单次提交 Agent 执行，避免手工转述和双提交。
- 让部署期 Extension 复用统一的命名空间、授权、参数上限、错误信封和 SSE 协议。
- 让 compact 结果以 operationId 写入历史，刷新、重连、重启后仍可恢复展示。
- 让所有会话资源按 JWT 身份、owner subject 与 agent scope 双重校验，阻断会话 ID、列表和前缀查询的信息泄露。

### 1.3 范围

| 类型 | 命令 | 谁来执行 | 不打开会话能否使用 |
|---|---|---|---|
| 内置本地 | /new、/resume [prefix] | CLIENT_LOCAL | 是 |
| 内置服务端 | /model、/thinking、/help、/settings、/compact | 服务端；改模型或思考模式时复用现有配置接口 | /help 可以；其他需要当前会话 |
| Skill | /skill:skill-name [arguments] | SERVER、SSE | 否 |
| Extension | /extensionId:command [arguments] | SERVER；可声明 SSE 和会话要求 | 由 descriptor 决定 |

name、export、浏览器端 Extension handler、Extension 热加载不属于本 Story。

---

## 2. Story 分析

### 2.1 Story 上下文

前端负责“看见、选择和发送命令”，服务端负责“判断这个用户能不能执行、真正执行、保存结果”。这样即使有人绕过前端直接调用接口，也不会跳过权限和命令校验。

~~~mermaid
flowchart LR
    user[终端用户]
    ui[Web 工作台<br/>App.vue / CommandMenu.vue]
    slash[useSlashCommands<br/>等价 parser、菜单、分流]
    api[useRuntimeApi<br/>HTTP / SSE 消费]
    auth[OAuth2 Resource Server<br/>JWT + RuntimePrincipalResolver]
    command[RuntimeCommandController<br/>RuntimeCommandService]
    catalog[WebCommandCatalog<br/>RuntimeSlashParser]
    event[RuntimeEventService<br/>events Slash 守卫]
    skill[RuntimeSkillResolver<br/>受管 Agent 目录]
    extension[SlashCommandExtension<br/>部署期 Spring SPI]
    compact[RuntimeCompactionCommandService<br/>History Projector]
    agent[AgentSessionFactory<br/>ManagedAgentSession / Agent]
    db[(GaussDB<br/>sessions + event history)]
    idp[身份提供方<br/>JWT issuer]
    llm[LLM Provider SDK]

    user --> ui --> slash --> api
    api --> auth
    idp -.签发 JWT.-> auth
    api --> command
    api --> event
    command --> catalog
    event --> catalog
    command --> skill
    event --> skill
    catalog --> extension
    command --> compact
    command --> agent
    event --> agent
    compact --> agent
    auth --> db
    command --> db
    event --> db
    compact --> db
    skill --> db
    agent --> llm
~~~

| 模块 | 做什么 | 不做什么 |
|---|---|---|
| 前端 | 识别输入、展示菜单、补全命令、调用接口、展示结果 | 不判断用户权限，不直接读 Skill 文件，不安装 Extension |
| 访问控制层 | 从 JWT 中识别当前用户，检查会话归属和权限 | 不相信浏览器传来的用户 ID、query 参数或 header |
| 命令层 | 管理命令目录、解析命令、调用对应处理器 | 不复用旧终端版 parser；不把已识别命令当聊天内容 |
| 普通消息层 | 处理正常聊天消息，阻止命令误走聊天接口 | 不负责 compact 的异步生命周期 |
| 数据库层 | 保存会话归属、历史记录和 compact 状态 | 不单独增加一张 compact 任务表 |
| 外部组件 | 提供 JWT、数据库、模型能力、部署期 Extension | Extension 不支持浏览器安装或热加载 |

### 2.2 功能点分解

#### 功能点清单

| 编号 | 功能点 | 优先级 | 参与方 | 做完后的结果 |
|---|---|---:|---|---|
| FS-00 | JWT 认证、owner 与权限 | P0 | 后端、DB、测试 | session 资源按 subject 和 agent scope 隔离 |
| FS-01 | 命令目录发现 | P0 | 前后端 | 静态目录与会话动态 Skill 目录分层 |
| FS-02 | Slash 解析与补全 | P0 | 前后端、测试 | 前后端 ParsedSlashInput 语义一致 |
| FS-03 | 内置服务端命令 | P0 | 前后端 | model、thinking、help、settings 正确路由 |
| FS-04 | 本地命令 | P0 | 前端、后端 | new、resume 在无会话场景可用 |
| FS-05 | compact 异步压缩 | P0 | 后端、DB、前端、测试 | 单操作、可恢复、可投影的状态机 |
| FS-06 | Skill 调用 | P1 | 后端、前端、测试 | 单次 SSE 执行和四类稳定错误 |
| FS-07 | Extension SPI | P1 | 后端、部署方、测试 | 部署期注册、命名空间与统一协议 |
| FS-08 | events Slash 守卫 | P0 | 后端、测试 | 已识别命令不进入普通 Agent prompt |
| FS-09 | 无会话入口 | P0 | 前后端、测试 | help、目录、LOCAL 命令无会话可用 |

#### 功能场景（开发和测试共用）

**FS-00：认证、授权与数据归属**

前提是历史会话已经补齐归属用户。用户带着有效 JWT 访问会话、消息、配置或命令时，服务端从 JWT 取得用户 ID、可访问的 Agent 和角色。

- 先检查会话是否属于该用户，再检查用户是否有该 Agent 和当前操作的权限。
- 无权访问和会话不存在都返回同一个 404，不能让调用者猜出别人是否有这个会话。
- JWT 缺失、伪造，或关键字段格式错误时返回 401。

**FS-01、FS-02：目录、解析与补全**

用户输入命令名之前，例如只输入 / 或 /mo，前端展示菜单。没有会话时只加载固定命令；有会话时再补充当前 Agent 可用的 Skill。

- 上下方向键只改变高亮项。
- Tab 或 Enter 只把选中的命令补到输入框，并在末尾加一个空格；菜单随即关闭，用户继续填参数。
- Cmd/Ctrl+Enter 会补全并马上执行；Escape 只关闭菜单，不丢失已经输入的文字。

**FS-03、FS-04：内置命令和前端分流**

用户点击发送后，前端必须先判断输入是不是命令，再决定是否发送普通消息。

- /new 和 /resume 只改变浏览器当前页面：前者离开当前会话，后者选择或恢复已有会话；两者都不删除服务端会话。
- /model 和 /thinking 的“修改”沿用现有配置接口和并发版本控制；查询、/help、/settings 走新命令接口。
- 只有未知命令或普通文本，才继续走现有的 sendMessage 流程。

**FS-09：无会话入口**

用户即使尚未打开会话，也能使用 /new、/resume 和 /help。前两个命令由浏览器完成，/help 调用无会话命令接口。无会话目录不会返回任何 Skill；普通聊天内容也不会因为用户输入而偷偷创建会话。

**FS-05：异步 compact**

用户有会话使用权限时可以提交 /compact。服务端先在数据库中记录“这次压缩已开始”，再启动实际任务；因此同一会话不会同时启动两次压缩。

接口只返回“压缩已启动”和 operationId，不提供实时进度流。收到成功响应后，前端立即显示“压缩中”，并禁用当前会话的文本输入、发送、附件、Slash 菜单和 steer/follow-up；用户仍可切换到其他会话。前端随后从历史记录中按 operationId 找到完成、失败、挂起或解除挂起的结果，只有完成、普通失败或解除挂起后才恢复输入。

**FS-06、FS-07、FS-08：Skill、Extension 与 events 守卫**

用户调用 /skill:名称 时，服务端只会从当前会话所属 Agent 的受管目录读取 Skill。读取后的内容和用户参数只组成一次 Agent 请求，并在同一个 HTTP 请求中返回流式结果；如果流还没开始就出错，则返回普通 JSON 错误。

Extension 由部署方随应用一起安装。应用启动时检查其名称、命名空间、保留字、重名和执行方式，发现冲突就拒绝启动。

直接调用普通 events 接口时，已注册命令会被拒绝并提示使用 commands 接口；格式正确的 Skill 名无论是否存在都要进入 SkillResolver，不能被当作普通聊天；只有未知的非 Skill 斜杠文本才继续交给 Agent。

---

## 3. 实现设计

### 3.1 功能实现思路

本节先说明改哪里、为什么改。具体类名是给开发人员定位用的；不熟悉代码时，先看每行的“设计内容和影响”。

#### 3.1.1 关键设计决策

1. **不直接拿旧终端命令代码来用。** 旧代码可以参考命令名称和帮助文案，但它的解析规则不适合 Web。需要新建 Web 专用解析器、命令目录和命令服务，避免前后端对同一句输入理解不一致。
2. **所有会话操作先过权限检查。** 当前 Runtime 没有统一的用户身份。要先接入 OAuth2 JWT，再让所有读取会话、发消息、改配置、执行命令的入口都使用同一套校验。
3. **先判断命令，再判断是否有会话。** 现在 App.vue 会先检查会话是否存在，导致无会话的 /new、/resume、/help 根本到不了命令处理。修改后保留用户原始输入，先识别命令，普通聊天才继续走旧逻辑。
4. **根据服务端响应类型展示结果。** 普通命令一次返回 JSON；Skill 和部分 Extension 会持续返回 SSE。前端必须先看响应类型，命令失败时不再把同一段文字当聊天消息重发。
5. **把 compact 当作后台任务。** 接口成功只表示任务已启动，不表示已经压缩完。真正的结果写进会话历史，页面按同一个 operationId 找回状态；内存中的单飞标记只用来减少重复请求，不能作为正确性的依据。

#### 3.1.2 新增和修改类

| 改造类型 | 代码位置 | 要做什么，以及会影响什么 |
|---|---|---|
| 新增 | runtimeapi/access/RuntimePrincipal、RuntimePrincipalResolver、RuntimeSessionAccessService | 从 Spring Security 已验证 JWT 建立身份和权限；所有 session 资源统一通过此入口校验 |
| 修改 | Security 配置、pom.xml、application.yml | 接入 OAuth2 Resource Server，校验 issuer、签名、过期、audience；未认证统一 401 |
| 修改 | RuntimeSessionRepository、MyBatisRuntimeSessionRepository、RuntimeSessionMapper | 新增 owner 过滤的 find/list/prefix，以及 compact 三类行锁原子操作 |
| 新增 | runtimeapi/command/RuntimeSlashParser、ParsedSlashInput | 唯一 parser；保留第一个 separator 后的原始参数，提供 name、arguments、hasSeparator |
| 新增 | WebCommandDefinition、WebCommandCatalog、RuntimeCommandService、RuntimeCommandController | 注册 builtin/Extension、目录查询、SERVER 分发、CLIENT_LOCAL 拒绝与 commands HTTP 入口 |
| 新增/修改 | CommandDescriptorDTO、CommandResultDTO、CommandInvocationRequestVO、RuntimeErrorCode、RuntimeExceptionHandler | 固化 descriptor、结果、8 KB 参数验证和稳定错误信封 |
| 修改 | RuntimeEventService | 在普通 prompt 创建前使用同一 parser 和 catalog 守卫；合法 skill 调用同一 resolver |
| 新增 | RuntimeSkillResolver、SlashCommandExtension | Skill 安全枚举/读取/错误区分；Extension 部署期 SPI 和启动期校验 |
| 新增/修改 | RuntimeCompactionCommandService、RuntimeCompactionHistoryProjector、CompactionReconcileWorker、RuntimeEntryCodec、RuntimeEventType、RuntimeEventQueryService | compact 状态机、历史投影与恢复；只有 COMPLETED summary 回灌 Agent 上下文 |
| 新增 | frontend/src/composables/useSlashCommands.ts、frontend/src/components/CommandMenu.vue | 目录、parser 等价实现、补全、LOCAL/SERVER 分流、SSE/JSON 处理与错误码映射 |
| 修改 | frontend/src/App.vue、frontend/src/composables/useRuntimeApi.ts、history projector/timeline | 将命令分流前置；复用 consumeSse；恢复后重拉目录；按 operationId 投影 compact，并以每个 session 的 compactPendingOperationId 控制输入锁 |

#### 3.1.3 工作量与依赖

| 工作包 | 前置依赖 | 影响面 | 优先级 | 预估人日 |
|---|---|---|---:|---:|
| 授权、owner 迁移、授权查询 | 部署方 owner 映射、JWT 配置 | 全部 session HTTP API、GaussDB schema | P0 | 8–12 |
| Parser、Catalog、命令 HTTP 骨架 | 授权工作包 | events 守卫、错误模型、前后端共享用例 | P0 | 6–8 |
| LOCAL 命令、目录、补全、内置命令 | 命令骨架 | App.vue、useRuntimeApi、会话查询 API | P0 | 6–8 |
| compact 状态机与历史投影 | 命令骨架、仓储原子操作 | Agent session、事件 codec、历史查询、DB 事务 | P0，复杂度最高 | 12–16 |
| Skill 与 Extension | 授权、Catalog、Agent 目录 | 受管 Skill、SSE、Spring 扩展装配 | P1 | 8–10 |

这份估算已包含单元测试、集成测试和前端测试，合计约 40–54 人日；不包含身份提供方接入、历史数据归属梳理、部署和验收环境排期。

> [!WARNING]
> 授权 owner 迁移、events 守卫和 compact 会改变现有接口可达性、数据边界和并发行为。不得以临时前端隐藏、进程内锁或跳过身份校验替代正式实现。

### 3.2 功能实现设计

这一节描述系统收到一条输入后如何流转。图中的类名用于开发定位；正常阅读时可以顺着箭头看“用户输入 → 前端判断 → 服务端执行 → 页面展示”。

#### 3.2.1 输入解析、目录和执行主流程

~~~mermaid
sequenceDiagram
    participant U as 用户
    participant A as App.vue
    participant S as useSlashCommands
    participant R as Runtime API
    participant C as Command Service/Catalog
    participant E as RuntimeEventService
    participant G as Agent

    U->>A: 提交原始 draft
    A->>S: submit(draft)
    S->>S: parseSlashInput(draft)
    alt CLIENT_LOCAL
        S-->>A: 已处理，不调用 sendMessage
    else SERVER 命令
        S->>R: POST commands
        R->>C: JWT、session access、handler
        alt streaming
            C->>G: 单次执行
            G-->>S: SSE，同一 POST
        else JSON
            C-->>S: CommandResultDTO
        end
        S-->>A: 系统消息、effects、时间线更新
    else 未识别文本
        A->>A: 此时才检查 hasSession 与普通输入判空
        A->>R: POST events
        R->>E: Slash 守卫
        E->>G: 普通 prompt
    end
~~~

| 输入 | ParsedSlashInput | 菜单行为 | 后续动作 |
|---|---|---|---|
| /model | name=model，arguments 为空，hasSeparator=false | 显示 | 可补全或执行 |
| /model 加空格 | name=model，arguments 为空，hasSeparator=true | 收起 | 参数输入 |
| /model 后换行和空白参数 | arguments 原样保留 | 收起 | 原样传服务端 |
| 仅斜杠或非首字符斜杠 | null | 不显示 | 普通输入语义 |

#### 3.2.2 各命令的详细处理

下表先给出每个命令的完整落点。后面的分项说明用于前端、后端和测试共同确认细节。

| 命令 | 是否需要会话 | 前端要做什么 | 服务端或本地处理 | 成功后的页面反馈 |
|---|---|---|---|---|
| /new | 否 | 清空当前会话视图和草稿 | 仅浏览器本地处理 | 显示已离开当前会话，进入欢迎态 |
| /resume [prefix] | 否 | 查询候选、让用户选择或直接恢复 | 调用会话列表或前缀查询接口 | 打开会话、加载历史、刷新命令目录 |
| /model [model-id] | 是 | 空参数查询；有参数时提交配置修改 | 查询走命令接口；修改复用现有模型配置接口 | 显示当前模型或模型已切换 |
| /thinking [level] | 是 | 空参数查询；有参数时提交配置修改 | 查询走命令接口；修改复用现有思考配置接口 | 显示当前级别或设置已更新 |
| /help | 否 | 调用无会话命令接口并展示结果 | 返回静态命令帮助，不包含 Skill | 时间线显示可用命令说明 |
| /settings | 是 | 调用会话命令接口并展示摘要 | 读取当前会话模型、思考模式和基础信息 | 时间线显示只读设置摘要 |
| /compact | 是 | 显示“压缩中”并锁定当前会话输入，后续刷新历史 | 启动异步压缩并写入状态事件 | 显示开始、完成、失败或挂起；满足解除条件后恢复输入 |
| /skill:名称 参数 | 是 | 以流式模式消费同一个命令请求 | 安全读取当前 Agent 的 Skill 后单次调用 Agent | 正常展示 Agent 流式回复 |
| /扩展:命令 参数 | 按 descriptor | 根据 descriptor 选择 JSON 或流式消费 | 交给部署期注册的 Extension handler | 展示 Extension 返回结果或流式回复 |

#### 3.2.2.1 每个命令调用的组件和工具

这里的“工具”分为两类：前端和后端的实现组件，以及 Agent 在执行过程中可能调用的模型工具。new、resume、model、thinking、help、settings 都不会让模型执行工具；Skill、普通聊天和部分 Extension 会进入 Agent 执行链路。

| 命令 | 前端调用 | 服务端调用 | 会不会调用 Agent 或模型工具 |
|---|---|---|---|
| /new | App.vue 的 clearSessionView | 无 | 不会 |
| /resume | 新增会话列表或前缀查询方法、getSession、loadHistory、重新加载命令目录 | RuntimeSessionController、RuntimeSessionService、授权查询 Repository | 不会 |
| /model 查询 | useSlashCommands 的 commands 请求方法 | RuntimeCommandService、既有 RuntimeSessionConfigurationService、RuntimeModelManager | 不会 |
| /model 修改 | useRuntimeApi.changeModel，带 If-Match | RuntimeSessionConfigurationController、RuntimeSessionConfigurationService、RuntimeModelManager、Repository.updateModel | 不会 |
| /thinking 查询 | useSlashCommands 的 commands 请求方法 | RuntimeCommandService、既有 RuntimeSessionConfigurationService | 不会 |
| /thinking 修改 | useRuntimeApi.changeThinking，带 If-Match | RuntimeSessionConfigurationController、RuntimeSessionConfigurationService、Repository.updateThinking | 不会 |
| /help | useSlashCommands 的无会话 commands 请求 | RuntimeCommandController、RuntimeCommandService、WebCommandCatalog | 不会 |
| /settings | useSlashCommands 的会话 commands 请求 | RuntimeCommandController、RuntimeCommandService、RuntimeSessionAccessService | 不会 |
| /compact | commands 请求、loadHistory、按 operationId 更新时间线、compactPendingOperationId 输入锁 | RuntimeCompactionCommandService、Repository 原子操作、AgentSessionFactory、ManagedAgentSession.compact、SessionCompactor、HistoryProjector | 会调用模型生成压缩摘要；不调用 Agent 的业务工具 |
| /skill:名称 | commands 请求、useRuntimeApi.consumeSse | RuntimeSkillResolver、AgentSessionFactory、ManagedAgentSession.prompt、RuntimeEventProjector | 会进入 Agent；Agent 是否调用 Read、Find、Grep 等已配置工具取决于 Skill 内容和模型决策 |
| /扩展:命令 | 按 descriptor 调用 JSON 或 SSE | WebCommandCatalog、对应 SlashCommandExtension handler | 由 Extension 自己声明；必须在 handler 内显式实现，不能由浏览器任意指定 |
| 未知 /xxx | useRuntimeApi.sendMessage | RuntimeEventService、现有普通消息执行链路 | 与普通聊天相同，模型可按现有规则调用已配置工具 |

> [!NOTE]
> /compact 需要模型生成摘要，但它不是把“/compact”交给 Agent 当作聊天内容，也不会经过 Read、Find、Grep 等 Agent 工具。Skill 则相反：它会将 Skill 内容和用户参数组成一次 Agent 请求，之后是否调用工具由 Agent 的正常执行规则决定。

**/new**

1. 前端识别到完整命令后，调用现有的清空会话视图能力，并清空输入框。
2. 不调用 commands 接口，也不删除或关闭服务端会话；用户之后可通过 /resume 回到它。
3. 无论当前是否已有会话都可执行。手机窄屏下沿用现有的新会话交互，自动收起侧栏。

**/resume**

1. 没有参数时，前端请求已授权会话列表，展示可恢复的会话。
2. 带前缀时，前端调用前缀查询接口。只有返回一条 matches 且 hasMore 为 false 时，才直接打开会话。
3. 多条结果、没有结果，或 hasMore 为 true 时，前端展示候选列表，不能猜测用户想打开哪一条。
4. 用户选中或直接命中会话后，前端加载该会话历史，并重新请求带 sessionId 的命令目录；这样不同 Agent 的 Skill 不会串到新会话。
5. 列表、前缀和打开会话都由服务端按 owner 与 agent 权限过滤，前端不得在本地根据 ID 推断权限。

**/model 与 /thinking**

1. 用户不传参数时，前端走 commands 查询接口，并将当前值以系统消息显示。
2. 用户传入新值时，前端复用现有 PUT 配置接口，同时带上 If-Match。这样可以避免两个页面同时修改配置时后写覆盖先写。
3. 修改成功后，前端更新标题栏中的模型或思考模式，并把结果写入时间线。
4. 配置冲突、模型不可用、当前模型不支持思考等既有配置错误，继续使用现有错误码和错误展示方式；失败时保留输入。

**/help**

1. /help 不依赖当前会话，调用 POST /commands/help。
2. 首版只展示静态命令，也就是内置命令和部署期 Extension；不会在无会话场景泄露任何 Skill 名称。
3. 前端把返回的帮助内容作为系统消息展示，不创建会话，也不发送给 Agent。

**/settings**

1. 该命令必须有当前会话。没有会话时返回 COMMAND_REQUIRES_SESSION，并提示用户先新建或恢复会话。
2. 服务端在完成授权后读取当前会话的模型、思考模式和基础信息，返回一个只读摘要。
3. 前端只展示结果，不产生设置修改，也不需要刷新 ETag。

**/compact**

1. 用户提交命令后立即禁用当前会话输入。成功响应返回 operationId 后，页面显示“压缩中”；这不等于压缩完成。
2. 前端把 operationId 保存为该 session 的 compactPendingOperationId。文本输入、发送、附件、Slash 菜单和 steer/follow-up 都由同一个输入锁禁用；切换到其他会话不受影响。
3. 前端通过历史接口查找同一 operationId 的后续事件，并更新同一条时间线状态。STARTED 或活跃 SUSPENDED 保持锁定；COMPLETED、没有活跃禁止态的 FAILED、SUSPENDED_CLEARED 后恢复输入。
4. 首版不提供取消按钮，也不建立实时进度 SSE。网络超时或响应不确定时，前端先刷新历史再决定是否恢复输入；不能直接假定压缩没有启动。

**/skill:名称**

1. 该命令必须有会话。前端不读取本地文件，也不根据菜单缓存判断 Skill 是否存在。
2. 服务端按当前会话的 Agent 查找受管目录中的 Skill，并保留用户参数的原始空白和换行。
3. 成功时，服务端只发起一次 Agent 执行，并在当前命令请求中返回 SSE；前端不得再补发普通 events 请求。
4. 未找到、不可见、已禁用、路径不安全分别返回稳定错误码。前端显示错误但不把该输入交给模型。

**Extension 命令**

1. Extension 命令的名称格式为 extensionId:command，例如 jira:create。它由部署方随应用安装，浏览器不负责安装或加载。
2. 前端从命令 descriptor 读取“是否需要会话”和“是否流式”，并按这两个字段调用和展示。
3. 服务端对 Extension 使用与内置命令相同的用户授权、参数大小限制和错误信封。Extension handler 只能获得已经授权的会话上下文。
4. 应用启动时发现命名冲突、非法名称、使用 skill 保留命名空间，或声明为本地执行的 Extension 命令，均应启动失败。

**未知斜杠文本**

1. 未注册的普通斜杠文本，例如 /abc 说明，继续当作普通聊天发送。
2. 已注册的内置或 Extension 命令如果错误地走了 events 接口，服务端返回 COMMAND_NOT_ROUTED，绝不把它发给模型。
3. 只要名称符合 skill:语法，即使 Skill 实际不存在，也必须走 Skill 解析流程并返回 Skill 错误，不能退回成普通聊天。

#### 3.2.3 compact 状态机

~~~mermaid
stateDiagram-v2
    [*] --> Admitting: POST compact
    Admitting --> Started: 行锁事务写 STARTED(operationId)
    Admitting --> RejectedRunning: session 正在执行
    Admitting --> RejectedInProgress: 409 COMPACTION_IN_PROGRESS
    Admitting --> Suspended: 超时 operation 写 FAILED + SUSPENDED
    Admitting --> RejectedSuspended: 409 COMPACTION_SUSPENDED
    Started --> Completed: operation open 且 activeLeafId 未变化
    Started --> Failed: 执行失败、启动失败或 leaf 冲突
    Started --> Suspended: 超时观察到未终态
    Suspended --> Cleared: 运维受权清除<br/>或单实例可验证 worker 已停止
    Cleared --> Admitting: 后续新请求
    Completed --> [*]
    Failed --> [*]
~~~

1. 服务端在同一个数据库事务里检查这个会话有没有正在压缩或已经挂起的压缩。没有冲突才写入“已开始”记录，并生成 operationId。
2. 数据库提交成功后，才真正启动压缩任务。这样数据库提交失败时，不会留下一个看似正在运行、实际不存在的任务。
3. 单独的历史投影器负责把“开始、完成、失败”写入会话历史，并保证一次压缩最多出现一个最终结果。
4. 写“完成”前要检查压缩期间有没有新消息。若有新消息，记录为失败而不是把旧摘要写回去，从而保护新消息。
5. 如果超时，服务端同时写“失败”和“已挂起”。之后的晚到回调只能收尾，不能再写第二个结果，也不能自行解除挂起。
6. 刷新页面、重连和重新打开会话时，前端必须从历史 entry 重建 compactPendingOperationId 和输入锁；不能只依赖内存中的请求结果。

#### 3.2.4 异常流程与用户体验

| 场景 | 服务端行为 | 前端体验 | 是否可重试 |
|---|---|---|---|
| JWT 缺失、无效或 claim 错误 | 401 | 保留草稿，提示认证失效 | 登录后 |
| 会话无权或不存在 | SESSION_NOT_FOUND，404 | 不展示存在性差异，回到可见会话 | 否 |
| 命令需会话 | COMMAND_REQUIRES_SESSION，400 | 提示先 new 或 resume | 是 |
| 参数超过 8 KB 或非字符串 | ARGUMENTS_TOO_LARGE，400 | 保留输入，提示限制 | 修改后 |
| 静态命令走 events | COMMAND_NOT_ROUTED，400 | 提示使用命令入口，不发给模型 | 前端修复后 |
| Skill 不存在或不可见 | SKILL_NOT_FOUND 或 SKILL_NOT_VISIBLE，404 | 显示不可用，不发给模型 | 切换会话或修复 Skill |
| Skill 禁用或路径不安全 | SKILL_INVOCATION_DISABLED 或 SKILL_PATH_INVALID，422 | 显示不可调用，不发给模型 | 管理员修复后 |
| 流开始前失败 | JSON 错误信封 | 由 content-type 分流，不能按 SSE 解析 | 按错误类型 |
| compact 进行中或禁止态 | 409 | 刷新历史显示关联 operation；活跃操作保持输入禁用；不显示浏览器端清除按钮 | 进行中否；禁止态由运维 |
| 网络超时或请求不确定 | 不假定执行结果 | 保留草稿并刷新历史；查到 active compact 则保持输入禁用，否则恢复输入 | 查询后决定 |

### 3.3 GUI 前端设计

本 Story 不增加独立页面，所有能力都在现有聊天输入框和时间线中完成。

#### 3.3.1 低保真设计

低保真设计见：[frontend-slash-command-low-fidelity.html](frontend-slash-command-low-fidelity.html)。

页面以状态切换形式展示：打开菜单、模型与思考模式、创建或恢复会话、压缩、Skill、Extension、帮助、设置、未知命令，以及会话正在执行时的命令处理方式。

#### 3.3.2 页面功能说明

| 区域或状态 | 功能描述 | 前端实现要点 |
|---|---|---|
| Composer 命令菜单 | 输入斜杠后展示当前可用 descriptor，支持分类、描述、参数提示和禁用态 | 仅 parsed 非空且 hasSeparator=false 时显示；目录加载失败静默降级为无菜单 |
| 键盘补全 | 方向键选择；Tab/Enter 补全；Cmd/Ctrl+Enter 补全后执行；Escape 关闭 | 补全写入斜杠加 descriptor.name 加空格，不走普通发送 |
| new | 清空当前会话视图并显示系统反馈 | 不删除服务端 session，不发 commands 请求 |
| resume | 无参数列会话；前缀查询时展示候选或直达 | 仅 matches 一条且 hasMore=false 才直达；恢复后刷新 session-aware 目录 |
| 同步命令结果 | help、settings、空参数查询在时间线展示系统反馈 | CommandResultDTO.output 不作为 Agent 历史持久化 |
| Skill 与 streaming Extension | 同一 POST 建立 SSE，复用消息流展示 | 先检查 content-type；流前 JSON 错误进入统一 friendlyError |
| compact | 显示“压缩中”并禁用当前会话输入，后续通过历史 entry 更新状态 | 必须按 operationId 关联，不能通过文案推断；完成、普通失败或解除挂起后才解锁 |
| 错误状态 | 权限、参数、不可用和并发错误保留输入并提示下一步 | 只能按 errorCode 决策，禁止匹配错误文案 |

#### 3.3.3 前端组件和接口使用

| 前端模块 | 使用接口 | 职责 |
|---|---|---|
| useSlashCommands.ts | 目录 API、commands API、sessions 列表/prefix API、useRuntimeApi.consumeSse | 目录加载、parser、补全、LOCAL/SERVER 分流、8 KB 前检、系统消息 |
| CommandMenu.vue | SlashCommandDescriptor | 根据 category、argsHint、streaming、requiresSession 渲染 listbox、activeIndex 与禁用项 |
| App.vue | useSlashCommands.submit(draft)、runtime.sendMessage | 将 Slash 分流放在 hasSession 和 running/follow-up 分支之前 |
| useRuntimeApi.ts | fetch、既有 consumeSse、history API | 普通消息继续 trim；命令保留原始 arguments，并按 JSON/SSE content-type 分流 |

### 3.4 接口描述

#### 3.4.1 通用约束

基础路径：/campusclaw-service/v1。

- 所有接口使用 Authorization Bearer JWT；OAuth2 Resource Server 校验 issuer、签名、过期和 audience。
- arguments 以 UTF-8 JSON 编码后最大 8 KB；内部空白和换行必须原样保留。
- session 资源读取后立即校验 owner、agent scope 和权限；资源不可见统一返回 SESSION_NOT_FOUND(404)。

#### 3.4.2 HTTP 接口

| 接口 | 请求 | 响应 | 使用场景 |
|---|---|---|---|
| GET /commands?scope=static | 无会话 | 静态 builtin 加 Extension descriptor | 初始菜单、无会话 help |
| GET /commands?sessionId=id | 已授权 session | 静态 descriptor 加当前 agent 可见 Skill | 当前会话菜单、resume 后刷新 |
| GET /sessions?agentId=agentId&limit=limit&cursor=cursor | agentId 仅筛选 | 稳定游标会话页 | resume 无参数候选 |
| GET /sessions?sessionIdPrefix=prefix&limit=20 | prefix | matches 加 hasMore | resume 前缀查询 |
| POST /commands/name | JSON arguments | JSON CommandResultDTO | 无会话服务端命令，首版主要 help |
| POST /sessions/id/commands/name | JSON arguments | JSON CommandResultDTO 或 text/event-stream | 会话 SERVER 命令、Skill、Extension |
| PUT /sessions/id/model | 既有 body 和 If-Match | 既有配置响应与新 ETag | model 写操作 |
| PUT /sessions/id/thinking | 既有 body 和 If-Match | 既有配置响应与新 ETag | thinking 写操作 |
| GET /sessions/id/events | 既有分页参数 | 历史 entries | compact 状态恢复和时间线投影 |
| POST /sessions/id/events | 普通消息 | 既有 SSE | 未识别文本；服务端执行 Slash 守卫 |

非流式命令统一返回：

~~~json
{
  "kind": "ok",
  "output": "已完成",
  "operationId": null,
  "effects": {}
}
~~~

compact 启动成功时 operationId 非空。Skill 或 streaming=true 的 Extension 在同一个命令 POST 返回 text/event-stream，禁止再提交第二个 events 请求。

#### 3.4.3 程序接口与 DTO

| 接口或类型 | 核心方法或字段 | 说明 |
|---|---|---|
| RuntimeSlashParser | parseSlashInput | 唯一服务端 parser；前端使用共享测试向量实现等价语义 |
| ParsedSlashInput | name、arguments、hasSeparator | 参数区绝不 trim、折叠或标准化 |
| WebCommandCatalog | isStaticRegistered、staticDescriptors | 启动期 builtin/Extension 目录和 events 守卫来源 |
| WebCommandDefinition | name、descriptor 元数据、handler | SERVER handler 只接收已授权 CommandExecutionContext |
| SlashCommandExtension | extensionId、commands | 部署期 Spring SPI；只允许 SERVER 命令 |
| RuntimeSkillResolver | descriptor 与安全读取 Skill | 区分 Not Found、Not Visible、Disabled、Path Invalid |
| CommandDescriptorDTO | name、description、argsHint、category、executionMode、requiresSession、streaming、sourceExtensionId | 前端菜单唯一数据模型 |
| CommandInvocationRequestVO | 可选 arguments | 缺失按空串；类型或大小错误为 ARGUMENTS_TOO_LARGE |
| CommandResultDTO | kind、output、operationId、effects | 非流式命令统一结果 |

#### 3.4.4 错误码

| 错误码 | HTTP | 前端处理 |
|---|---:|---|
| COMMAND_NOT_FOUND | 404 | 提示未知命令，不重试 |
| COMMAND_NOT_ROUTED | 400 | 提示命令入口错误，不发送给模型 |
| COMMAND_CLIENT_LOCAL | 400 | 记录前端未实现诊断并显示通用失败 |
| COMMAND_REQUIRES_SESSION | 400 | 提示新建或恢复会话 |
| ARGUMENTS_TOO_LARGE | 400 | 保留输入，提示 8 KB 上限 |
| COMPACTION_IN_PROGRESS | 409 | 提示已有压缩进行中并刷新历史 |
| COMPACTION_SUSPENDED | 409 | 显示禁止态，不暴露浏览器端清除 |
| SKILL_NOT_FOUND、SKILL_NOT_VISIBLE | 404 | 提示 Skill 不可用，不发给模型 |
| SKILL_INVOCATION_DISABLED、SKILL_PATH_INVALID | 422 | 提示 Skill 不可调用，不发给模型 |

### 3.5 数据库及文件持久化设计

#### 3.5.1 会话归属与迁移

当前 t_sessions 没有 owner 字段，需要如下变更：

| 对象 | 变更 | 用途 |
|---|---|---|
| t_sessions.owner_subject_id VARCHAR(128) NOT NULL | 创建时写入 RuntimePrincipal.subjectId，普通命令不可修改 | owner 级会话隔离 |
| idx_t_sessions_owner_agent_updated | owner_subject_id、agent_id、updated_at DESC、id 复合索引 | resume 列表和前缀查询的授权过滤、稳定排序 |
| GaussDB upgrade 脚本 | 加可空列、权威映射回填、归档无法确认记录、验证无 NULL、收紧 NOT NULL、建索引 | 存量数据安全升级 |

Repository 必须以 subjectId 为首要条件执行 findOwned、listAuthorized、findAuthorizedByPrefix；禁止先全表按 sessionId 或 prefix 查询、再在内存过滤。

#### 3.5.2 compact 事件持久化

不新增独立 operation 表。每次压缩以 operationId 写入既有 t_session_entries 事件历史，并由 RuntimeEntryCodec 与查询服务识别：

| 事件类型 | 必填 payload | 写入时机 | 是否回灌 Agent 上下文 |
|---|---|---|---|
| SESSION_COMPACTION_STARTED | operationId、startedAt | 准入事务 | 否 |
| SESSION_COMPACTION_COMPLETED | operationId、reason、keptMessages、removedMessages、completedAt | operation open 且 leaf 未变化 | 是，summary |
| SESSION_COMPACTION_FAILED | operationId、errorCode、failedAt | 执行失败或 leaf 冲突 | 否 |
| SESSION_COMPACTION_SUSPENDED | operationId、reason、suspendedAt | timeout 与 failed 同事务 | 否 |
| SUSPENDED_CLEARED | suspendedOperationId、actor、clearReason、clearedAt | 运维清除或单实例可验证停止 | 否 |

#### 3.5.3 一致性与恢复

- admitCompaction、tryAppendTerminalIfOpen、tryClearSuspensionIfCurrent 均在同一 session 行锁事务中执行。
- 一个 STARTED 最多一个 COMPLETED 或 FAILED；晚到回调只能释放本地资源。
- 活跃 SUSPENDED 在重启后仍拒绝新压缩；没有 lease/fencing 时禁止自动启动替代操作。
- RuntimeEntryCodec 只把 COMPLETED 恢复为 Agent summary；其余四类 entry 恢复为 null，避免污染模型上下文。
- CompactionReconcileWorker 仅补偿无终态 started 或终态写失败，不得按超时自动解除禁止态或创建新压缩。

#### 3.5.4 Skill 文件持久化边界

Skill 不由命令执行过程写入。受管目录由既有 Agent Runtime 管理，逻辑结构为 agent 目录下的 .campusclaw/skills/skillName/SKILL.md；RuntimeSkillResolver 只能在已授权 session 对应的 agent 根目录内安全读取。

| 文件对象 | 持久化责任 | 本 Story 行为 |
|---|---|---|
| SKILL.md 与 skill.json | 既有 AgentRuntimeManager 的 prepare 或 refresh 流程原子发布 | Resolver 复用 real-path、符号链接、扫描深度和文件大小保护，不接受浏览器传入路径 |
| references、templates | 既有受管 Skill 目录 | 本期不经 Slash 接口浏览、上传或修改 |
| Skill 注入文本 | 命令执行期内存数据 | 读取后最大注入 16 KB；超出部分由服务端截断并在注入消息中说明 |

---

## 4. 验收与验证

### 4.1 关键验收项

- JWT、owner subject、agent scope 与权限在列表、前缀、事件、配置、命令全路径生效；无权会话不可被枚举或探测。
- 前后端共享 parser 用例覆盖空白、换行、仅斜杠、参数原样保留和 hasSeparator。
- new、resume、help 在无会话时可执行；普通消息仍要求有效会话。
- events 不会把静态命令或合法 skill 名称交给模型；未知非 Skill /xxx 仍保持普通 prompt。
- Skill 覆盖目录隔离、四类错误、单次 SSE 与原样 arguments；Extension 覆盖 namespace、保留字、SERVER-only 与参数校验。
- 并发 compact 只产生一个 STARTED；leaf 冲突不覆盖新消息；timeout、重启和清除满足单终态与禁止态规则。
- compact 启动请求、刷新、重连和重新进入会话均正确重建输入锁：STARTED/活跃 SUSPENDED 禁用输入，COMPLETED、普通 FAILED 或 SUSPENDED_CLEARED 恢复输入；网络不确定时先查询历史。

### 4.2 建议验证命令

~~~bash
# 后端：JDK 21
./mvnw -pl :campusclaw-coding-agent -am test
./mvnw spotless:check checkstyle:check

# 前端
cd frontend && npm test && npm run typecheck
~~~

## 版本历史

| 日期 | 说明 |
|---|---|
| 2026-08-28 | 按 Story 标准重构为上下文、Feature Scenario、实现思路、实现设计、GUI、接口和持久化的完整设计文档；内容来自同批归档中的主设计、Gap 分析与低保真图。 |
